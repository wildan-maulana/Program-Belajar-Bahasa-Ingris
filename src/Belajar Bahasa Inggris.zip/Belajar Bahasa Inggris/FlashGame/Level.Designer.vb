﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Level
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Level))
        Me.Level5m = New System.Windows.Forms.PictureBox
        Me.Level4m = New System.Windows.Forms.PictureBox
        Me.Level3m = New System.Windows.Forms.PictureBox
        Me.Level2m = New System.Windows.Forms.PictureBox
        Me.Level5 = New System.Windows.Forms.PictureBox
        Me.Level4 = New System.Windows.Forms.PictureBox
        Me.Level3 = New System.Windows.Forms.PictureBox
        Me.Level2 = New System.Windows.Forms.PictureBox
        Me.Level1 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        CType(Me.Level5m, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level4m, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level3m, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level2m, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Level1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Level5m
        '
        Me.Level5m.Image = Global.FlashGame.My.Resources.Resources.lima
        Me.Level5m.Location = New System.Drawing.Point(740, 200)
        Me.Level5m.Name = "Level5m"
        Me.Level5m.Size = New System.Drawing.Size(100, 102)
        Me.Level5m.TabIndex = 8
        Me.Level5m.TabStop = False
        '
        'Level4m
        '
        Me.Level4m.Image = Global.FlashGame.My.Resources.Resources.empat
        Me.Level4m.Location = New System.Drawing.Point(597, 200)
        Me.Level4m.Name = "Level4m"
        Me.Level4m.Size = New System.Drawing.Size(100, 102)
        Me.Level4m.TabIndex = 7
        Me.Level4m.TabStop = False
        '
        'Level3m
        '
        Me.Level3m.Image = Global.FlashGame.My.Resources.Resources.tiga
        Me.Level3m.Location = New System.Drawing.Point(457, 200)
        Me.Level3m.Name = "Level3m"
        Me.Level3m.Size = New System.Drawing.Size(100, 102)
        Me.Level3m.TabIndex = 6
        Me.Level3m.TabStop = False
        '
        'Level2m
        '
        Me.Level2m.Image = Global.FlashGame.My.Resources.Resources.dua
        Me.Level2m.Location = New System.Drawing.Point(311, 200)
        Me.Level2m.Name = "Level2m"
        Me.Level2m.Size = New System.Drawing.Size(100, 102)
        Me.Level2m.TabIndex = 5
        Me.Level2m.TabStop = False
        '
        'Level5
        '
        Me.Level5.Image = Global.FlashGame.My.Resources.Resources._5
        Me.Level5.Location = New System.Drawing.Point(740, 200)
        Me.Level5.Name = "Level5"
        Me.Level5.Size = New System.Drawing.Size(100, 102)
        Me.Level5.TabIndex = 4
        Me.Level5.TabStop = False
        '
        'Level4
        '
        Me.Level4.Image = Global.FlashGame.My.Resources.Resources._4
        Me.Level4.Location = New System.Drawing.Point(597, 200)
        Me.Level4.Name = "Level4"
        Me.Level4.Size = New System.Drawing.Size(100, 102)
        Me.Level4.TabIndex = 3
        Me.Level4.TabStop = False
        '
        'Level3
        '
        Me.Level3.Image = Global.FlashGame.My.Resources.Resources._3
        Me.Level3.Location = New System.Drawing.Point(457, 200)
        Me.Level3.Name = "Level3"
        Me.Level3.Size = New System.Drawing.Size(100, 102)
        Me.Level3.TabIndex = 2
        Me.Level3.TabStop = False
        '
        'Level2
        '
        Me.Level2.Image = Global.FlashGame.My.Resources.Resources._2
        Me.Level2.Location = New System.Drawing.Point(311, 200)
        Me.Level2.Name = "Level2"
        Me.Level2.Size = New System.Drawing.Size(100, 102)
        Me.Level2.TabIndex = 1
        Me.Level2.TabStop = False
        '
        'Level1
        '
        Me.Level1.Image = Global.FlashGame.My.Resources.Resources._1
        Me.Level1.Location = New System.Drawing.Point(159, 200)
        Me.Level1.Name = "Level1"
        Me.Level1.Size = New System.Drawing.Size(100, 102)
        Me.Level1.TabIndex = 0
        Me.Level1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Moccasin
        Me.Label1.Font = New System.Drawing.Font("Gill Sans MT", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(321, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(388, 67)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "SELECT LEVEL"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.BackColor = System.Drawing.Color.DarkTurquoise
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.ForeColor = System.Drawing.Color.Red
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel1.Location = New System.Drawing.Point(428, 484)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(80, 33)
        Me.LinkLabel1.TabIndex = 29
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Back"
        '
        'Level
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.FlashGame.My.Resources.Resources.level2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(971, 548)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Level5m)
        Me.Controls.Add(Me.Level4m)
        Me.Controls.Add(Me.Level3m)
        Me.Controls.Add(Me.Level2m)
        Me.Controls.Add(Me.Level5)
        Me.Controls.Add(Me.Level4)
        Me.Controls.Add(Me.Level3)
        Me.Controls.Add(Me.Level2)
        Me.Controls.Add(Me.Level1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Level"
        Me.Text = "Level"
        CType(Me.Level5m, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level4m, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level3m, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level2m, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Level1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Level1 As System.Windows.Forms.PictureBox
    Friend WithEvents Level2 As System.Windows.Forms.PictureBox
    Friend WithEvents Level3 As System.Windows.Forms.PictureBox
    Friend WithEvents Level4 As System.Windows.Forms.PictureBox
    Friend WithEvents Level5 As System.Windows.Forms.PictureBox
    Friend WithEvents Level2m As System.Windows.Forms.PictureBox
    Friend WithEvents Level3m As System.Windows.Forms.PictureBox
    Friend WithEvents Level4m As System.Windows.Forms.PictureBox
    Friend WithEvents Level5m As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
End Class
